import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

colors={"ITK":'r',"Parallel_GPU":'g',"Parallel_X86":'b',"Serial":'y'}

df = pd.read_csv('FMM_Timing.csv')
#print df.describe()

fig = plt.figure() # Create matplotlib figure
ax = fig.add_subplot(111) # Create matplotlib axes
my_plot = df.plot( ax=ax, x='Scenario', kind='barh')

ax.set_xlabel('ExecutionTime (milli-sec)')
ax.set_ylabel('Test Case')

plt.show()
fig = ax.get_figure()
fig.savefig('fig.png')

#df.plot(x='Environment',kind='barh')
#groups = df.groupby('Environment')
#print df.groupby('Environment').head()

#for name, group in df.groupby('Scenario'):
#    group.plot(x='Environment',kind='barh')

#df.groupby('Environment').plot(x='Scenario',kind='barh')
# Plot
#fig, ax = plt.subplots()
#ax.margins(0.05) # Optional, just adds 5% padding to the autoscaling
#for name, group in groups:
    #ax.plot(group.Scenario, group.TotalTime, marker='o', linestyle='', ms=12, label=name)
#    group.plot(x='Scenario', y='TotalTime', kind='bar')
#ax.legend()

#plt.show()

#plt.figure()
#for i, group in df.groupby('Environment'):
#    print i
    #plt.figure()
    #group.plot(x='Scenario', y='TotalTime', title=str(i), kind='bar', color=colors[i])
   