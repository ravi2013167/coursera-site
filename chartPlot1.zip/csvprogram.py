#importing modules
import csv
import sys
import webbrowser
import os
import struct
import itertools
import PIL.Image
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from pylab import *
import collections
from collections import defaultdict
csv_file = sys.argv[1]
log_file = sys.argv[2]
plot_dict = defaultdict(lambda: defaultdict(dict))
with open(csv_file , 'rb') as cf:
	csv_reader = csv.reader(cf, delimiter = ',')
	header = next(csv_reader)	
	scenario_description_count = len(header)
	image_dim_index = 0
	for columns in header:
		image_dim_index += 1
		print columns
		if('SrcImage0' in columns):
			break
	for row_csvfile in cf:
		if len(row_csvfile)<len(header) or row_csvfile[0].startswith('#'):
			continue
		row_csvfile = row_csvfile.split(',')
		print row_csvfile[image_dim_index]
		with open(log_file, 'rb') as lf:
			log_reader = csv.reader(lf, delimiter = ',')
			log_header = next(log_reader)
			log_description_count = len(log_header)
			for row_logfile in lf:
				if len(row_logfile)<len(log_header) or row_logfile[0].startswith('#'):
					continue
				row_logfile = row_logfile.split(',')
				if(row_csvfile[2] in row_logfile[0]):
					print row_logfile[image_dim_index]
					#plot_dict[row_csvfile[2]][row_csvfile[3]][image_dim_index]
