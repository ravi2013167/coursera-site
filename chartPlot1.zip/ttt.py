import numpy as np
import matplotlib.pyplot as plt

# fake data
np.random.seed(937)
data = np.random.lognormal(size=(37, 4), mean=1.5, sigma=1.75)
labels = list('ABCD')
fs = 10  # fontsize
print data
# demonstrate how to toggle the display of different elements:
#fig, axes = plt.subplots(nrows=2, ncols=3, figsize=(6, 6))
plt.boxplot(data)
#plt.set_title('Default', fontsize=fs)
plt.show()
