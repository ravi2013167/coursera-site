# -*- coding: utf-8 -*-
#!/usr/bin/env python

#########################################################
# This script depends on openpyxl module and            #
# utils/scripts/exec_quality_text.py output format      #
#                                                       #
# 1. install openpyxl                                   #
#    easy_install openpyxl                              #
#########################################################

import re
from openpyxl import Workbook
from openpyxl.charts import LineChart, Reference, Series, ScatterChart

#set ignore case for chart this is only for xlsx output
IGNORE_CASE = ["rocaX86"]

class TotalTimes():
    def __init__(self):
        self.sizes = {}

    def append(self, size, line):
        results = line.replace(" ", "").split(",")
        if len(results) > 5:
            #0:testName, 1:HD, 2:KE, 3:DH, 4:TT, 5:RMSE
            totalTime = results[2].split("\t")[0]
        else:
            return
        self.sizes[size] = float(totalTime)

    def getCsvString(self, format):
        s = ""
        for size in sorted([int(x) for x in self.sizes.keys()]):
            s += format%("%s, %s\n"%(size, self.sizes[str(size)]))
        return s

    def setValues(self, ws, device_name):
        for size in sorted([int(x) for x in self.sizes.keys()]):
            ws.append([device_name, size, self.sizes[str(size)]])
        return len(self.sizes.keys())

class Devices():
    def __init__(self):
        self.devices = {}
    
    def append(self, name, line):
        size = line.replace(" ", "").split(",")[0].split("_")[1]
        if not self.devices.has_key(name):
            self.devices[name] = TotalTimes()
        self.devices[name].append(size, line)

    def getCsvString(self, format):
        str = ""
        for name in sorted(self.devices.keys()):
            str += self.devices[name].getCsvString(format%(name+", %s"))
        return str

    def setValues(self, ws):
        ret = []
        for name in sorted(self.devices.keys()):
            ret.append([name, self.devices[name].setValues(ws, name)])
        return ret

class Algorithms():
    def __init__(self):
        self.algorithms = {}

    def append(self, name, line):
        results = line.replace(" ", "").split(",")
        device = results[0].split("_")[2]
        if not self.algorithms.has_key(name):
            self.algorithms[name] = Devices()
        self.algorithms[name].append(device, line)

    def getCsvString(self, format):
        str = ""
        for name in sorted(self.algorithms.keys()):
            str += self.algorithms[name].getCsvString(format%(name+", %s"))
        return str

    def createXlsx(self, filename):
        wb = Workbook()
        ws = wb.active
        wb.remove_sheet(ws)
        for name in sorted(self.algorithms.keys()):
            ws = wb.create_sheet(title=name)
            ranges = self.algorithms[name].setValues(ws) 
            #ranges = [device name, test case size]
            x = 1 #excel seeet start at 1
            chart = ScatterChart()
            chart.title = name
            allZero = True
            for i in ranges:
                if i[0] in IGNORE_CASE:
                    continue
                if i[1] != 0:
                    allZero = False
                else:
                    continue #zero range cause error
                values = Reference(ws, (x, 3), (x + i[1] - 1, 3))
                xvalues = Reference(ws, (x, 2), (x + i[1] - 1, 2))
                series = Series(values, title=i[0], xvalues=xvalues)
                chart.append(series)
                x += i[1]
            if not allZero: #non value chart cause error
                chart.x_axis.title = "pixel"
                chart.y_axis.title = "ms"
                chart.margin_left = .1
                chart.margin_top = .1
                chart.width = .8
                chart.height = .8
                chart.drawing.left = 400
                chart.drawing.top = 10
                ws.add_chart(chart)
        wb.save(filename)

class TestCaseParser():
    algorithms = Algorithms()
    nextIsTimeLine_ = False

    def __init__(self, filename):
        self.filename = filename

    def parseLine(self, line):
        if self.nextIsTimeLine_:
            name = line.replace(" ", "").split(",")[0].split("_")[0]
            self.algorithms.append(name, line)
            self.nextIsTimeLine_ = False
        if re.match("TestCase", line):
            self.nextIsTimeLine_ = True

    def execute(self):
        f = open(self.filename, "r")
        state = "END"

        for line in f:
            if state == "START":
                self.parseLine(line)
            if line.find("Executing") != -1:
                state = "START"
            if line.find("Complete") != -1:
                state = "END"
        f.close()

    def getCsvString(self):
        return self.algorithms.getCsvString("%s")

    def createXlsx(self, filename):
        return self.algorithms.createXlsx(filename)

p = TestCaseParser("./quality/result/consoleText")
p.execute()
#print p.getCsvString()
p.createXlsx("./result/algorithm_speeds.xlsx")

