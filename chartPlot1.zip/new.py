import numpy as np
import matplotlib.pyplot as plt

# sample data
x = np.arange(10)
y = 5*x 

# fit with np.polyfit
#m, b = np.polyfit(x, y, 1)

plt.plot(x, y, '.')
plt.plot(x, 5*x, '-')
plt.show()
