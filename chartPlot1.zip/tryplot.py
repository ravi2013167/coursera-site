import matplotlib.pyplot as plt
d = {'hello': 3, 'how': 4, 'yes': 10, 'you': 11, 'days': 10, 'are': 20, 'ago': 11}
plt.bar(range(len(d)), d.values(), align="center")
plt.xticks(range(len(d)), d.keys())
plt.show()
