import sys
import csv
import matplotlib.pyplot as plt
import numpy as np
import collections
import xlsxwriter
from collections import defaultdict

def autolabel(rects):
    # attach some text labels
    for rect in rects:
        height = rect.get_height()
        plt.text(rect.get_x() + rect.get_width()/2., 1.01*height,
                '%f' % float(height),
                ha='center', va='bottom')

xr = sys.argv[1]
xr1 = sys.argv[2]
with open(xr) as f:
	read_testfile = csv.reader(f, delimiter = ',')
	for row in read_testfile:
		if ('TestGroup') in row:
			test_group = row
		else:	
			if (row=='\n') or (('TestCase') in row) or len(row)<10 or (('Executing') in row) :
				continue
			else :
				yy = defaultdict(lambda: defaultdict(dict))
				gpu = defaultdict(dict)
				x86 = defaultdict(dict)
				for row_testfile in read_testfile:
					if(('TestCase') in row) or (row=='\n') or (row=='') or (len(row_testfile)<10):
						continue
					
					row_testfile =  map(str.strip, row_testfile)
					if('GPU' in row_testfile[0]):
						h = row_testfile[0].find('GPU')
					else:
						h = row_testfile[0].find('X86')
					x = row_testfile[0].find('x')
					#print row_testfile[0][x+1:]
					if ('x' in row_testfile[0][x+1:]):
						t = row_testfile[0][x+7:]
					else:
						t = row_testfile[0][x+5:]	
					x1  = row_testfile[0][0:h] + row_testfile[0][h+4:x-5] + t
					y1 = row_testfile[0][h:h+3]
					z = int(row_testfile[0][x-4:x])
					ex = row_testfile[2]
					with open(xr1) as fe:
						read_t = csv.reader(fe, delimiter = ',')
						for row_f in read_t:
							row_f =  map(str.strip, row_f)
							if(('TestCase') in row_f) or (len(row_f)<10 and len(row_f)!=6) or (row_f=='\n') or (row_f=='') :		
								print len(row_f), row_f								
								continue
							if(('Mean' in row_f[0])):
								ex = row_f[2]
								print ex
								print 'hola'
								yy[x1][y1][z] = float(ex)
								continue
							if(len(row_f) == 6 and ('Mean' not in row_f)):									
								continue
							if('GPU' in row_f[0]):
            							h = row_f[0].find('GPU')
          						else:
            	  						h = row_f[0].find('X86')
          						x = row_f[0].find('x')
		 					if ('x' in row_f[0][x+1:]):
            	  						t = row_f[0][x+7:]
          						else:
            	  						t = row_f[0][x+5:]
					  		x1  = row_f[0][0:h] + row_f[0][h+4:x-5] + t
					  		y1 = row_f[0][h:h+3]
							print x1, y1, row_f[0][x-4:x]
					  		z = int(row_f[0][x-4:x])
				#workbook  = xlsxwriter.Workbook('filename.xlsx')	
				print yy
				i=j=k=l=0
				for elem in yy:
					#print elem
					gpu['256'][i] = yy[elem]['GPU'][256]
					gpu['512'][j] = yy[elem]['GPU'][512]
					gpu['1024'][k]= yy[elem]['GPU'][1024]
					gpu['2048'][l]= yy[elem]['GPU'][2048]
					#x86['256'][i] = yy[elem]['X86'][256]
					#x86['512'][j] = yy[elem]['X86'][512]
					#x86['1024'][k]= yy[elem]['X86'][1024]
					#x86['2048'][l]= yy[elem]['X86'][2048]
					i+=1
					j+=1
					k+=1
					l+=1
					n_groups = 4
					index = np.arange(n_groups)
					bar_width = 0.35
					yy[elem]['GPU'] = collections.OrderedDict(sorted(yy[elem]['GPU'].items()))
					#yy[elem]['X86'] = collections.OrderedDict(sorted(yy[elem]['X86'].items()))
					#rects1 = plt.bar(index, yy[elem]['X86'].values() , bar_width, alpha=0.4, color='b', label='X86')
					rects2 = plt.bar(index + bar_width, yy[elem]['GPU'].values() , bar_width, alpha=0.4, color='g', label='GPU')
					plt.xticks(index + bar_width, ('256', '512', '1024', '2048'))
					plt.title(elem)
					plt.xlabel('Image Size')
					plt.ylabel('Execution Time')
					#autolabel(rects1)
					autolabel(rects2)
					plt.legend()
					#worksheet = workbook.add_worksheet()
					#worksheet.write(0, 0, 'Hello Excel')
					#workbook.close()
					#fig = plt.show()
					#fig.savefig(elem + '.png')
					plt.savefig(elem + '.png')
					#plt.show()
					#xar['1024'][k]
					plt.close()
				data1 = gpu['256'].values(), gpu['512'].values(), gpu['1024'].values(), gpu['2048'].values()
				#print data1
				plt.boxplot(data1)
				plt.show()
				#data2 = x86['256'].values(), x86['512'].values(), x86['1024'].values(), x86['2048'].values()
				#plt.boxplot(data2)
				#plt.show()
				
