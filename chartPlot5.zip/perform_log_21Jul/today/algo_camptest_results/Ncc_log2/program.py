#importing modules
import csv,sys,webbrowser,os,struct,itertools
import PIL.Image
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from pylab import *
import collections
#import xlsxwriter
from collections import defaultdict
try:
    # for Python2
    from Tkinter import *   ## notice capitalized T in Tkinter 
except ImportError:
    # for Python3
    from tkinter import *

#initialising variable to check if double data or image is displayed
from_display = 0

#create folder, Images to save images
if not os.path.exists("Images"):
    os.makedirs("Images")
    os.makedirs("Images/PerformanceTest")
def concat_images(imga, imgb):
    """
    Combines two color image ndarrays side-by-side.
    """
    ha,wa = imga.shape[:2]
    hb,wb = imgb.shape[:2]
    max_height = np.max([ha, hb])
    total_width = wa+wb
    new_img = np.zeros(shape=(max_height, total_width, 3), dtype=np.uint8)
    new_img[:ha,:wa]=imga
    new_img[:hb,wa:wa+wb]=imgb
    return new_img

def concat_n_images(image_path_list):
    """
    Combines N color images from a list of image paths.
    """
    output = None
    for i, img in enumerate(image_path_list):
        if i==0:
            output = plt.imread(img)[:,:,:3]
        else:
            output = concat_images(output,
                                   plt.imread(img)[:,:,:3])
    return output
def median(result_file_2) :
	with open(result_file_2) as fe:
		read_t = csv.reader(fe, delimiter = ',')
		for row_f2 in read_t:
			row_f2 =  map(str.strip, row_f2)
			if(('TestCase') in row_f2) or (len(row_f2)<10 and len(row_f2)!=6) or (row_f2=='\n') or (row_f2=='') :		
				#print len(row_f2), row_f2						
				continue
			if(('Median' in row_f2[0])):
				ex = row_f2[2]
				#print ex
				#print 'hola'
				yy[x1][y1][z] = float(ex)
				continue
			if(len(row_f2) == 6 and ('Median' not in row_f2)):									
				continue
			if('GPU' in row_f2[0]):
			        image_gpu=1
		    	     	h = row_f2[0].find('GPU')
		  	elif('X86' in row_f2[0]):
		    	     	image_x86=1
			     	h = row_f2[0].find('X86')
		   	elif('REF' in row_f2[0]):
			        image_ref=1
			        h = row_f2[0].find('REF')
			x = row_f2[0].find('x')
			if ('x' in row_f2[0][x+1:]):
          	                t = row_f2[0][x+9:]
			        if('_' in row_f2[0][x+1:]):
			     		l = row_f2[0][x+1:].find('_')
					ext = row_f2[0][x+5:l]
			        else:
					ext = row_f2[0][x+5:]
		  	else:
		    	        t = '' #row_f[0][x+5:]
			        ext = ''
			fe = min(x, h)	  		
			x1  = row_f2[0][0:fe] + row_f2[0][h+4:x-5] + t
	  		y1 = row_f2[0][h:h+3]
			#print y1
	  		z = int(row_f2[0][x-4:x])
my_dpi = 100
def merge_plot(a, b, c, d, count):
	#fig = plt.figure(frameon=False)
	#fig.set_size_inches(20, 5)
	i = 1
	j = 3
	k = 1
	files = []
	x_offset = 0
	for elem in yy:
		#print int(d), elem
		if(d==0):		
			if((elem[0] != '1') or ((c) in elem)):
				print elem + 'ff'				
				continue				
		else:
			if((elem[0] == str(d)) or ((c) in elem)):
				print elem, b, c				
				continue				
		
		print elem
		files.append('Images/PerformanceTest/' + test_file + '/' + elem + '.png')


		#a=fig.add_subplot(i,j,k)
		#img = mpimg.imread('Images/PerformanceTest/'+elem+'.png')
		#imgplot = plt.imshow(img)
				
		k+=1
		if(k%4==0):
			#plt.set_size_inches(18.5, 10.5)					
			#plt.figure(figsize=(20, 10.5))					
			#if(str(a)[0] == 'A')
			imgs = map(PIL.Image.open, files)
			min_shape = sorted( [(np.sum(i.size), i.size ) for i in imgs])[0][1]
			imgs_comb = np.hstack( (np.asarray( i.resize(min_shape) ) for i in imgs ) )

			# save that beautiful picture
			imgs_comb = PIL.Image.fromarray( imgs_comb)
			imgs_comb.save( 'Images/PerformanceTest/' + test_file + "/"+str(count)+'.png' )    
			#result = PIL.Image.new("RGBA", (total_width, max_height))			
			#for f in files:
				#result.paste(images, (0, 0))				
				#x_offset += images.size[0]			
			#result.save('Images/PerformanceTest/ads.png')
			#plt.savefig('Images/PerformanceTest/'+str(count)+'.png')
			
			#plt.close()
			count +=1
			files = []
			fig = plt.figure(frameon=False)
			fig.set_size_inches(25, 4)
			k = 1
			i = 1
		
	print '\n'
	plt.close()
def autolabel(rects):
    # attach some text labels
    for rect in rects:
        height = rect.get_height()
        plt.text(rect.get_x() + rect.get_width()/2., 1.01*height,
                '%0.1f' % float(height),
                ha='center', va='bottom')
    
#function to create thumbnail images
def createThumbnail(image_path ,image_folder, image_name, image_parameters, transform_type):
    from PIL import Image
    
    #if image files are jpg or bmp format, copy them to Images folder and create thumbnails
    if image_name.endswith(".jpg") or image_name.endswith(".bmp"):
        create_direc = '''Images/%s'''%(image_folder)
        
        if not os.path.exists(create_direc):
            os.makedirs(create_direc)
        #the first image_folder should be changed to image_path if folders testdata and Dump exist in same location
        copy_statement = "cp %s/%s/%s Images/%s/%s" %(path_of_files,image_folder,image_name,image_folder,image_name)
        os.system(copy_statement)
        size = 40,40
        path_save_image = "Images/%s/%s"%(image_folder,image_name)
        image_thumbnail = Image.open(path_save_image)
        image_thumbnail.thumbnail(size, Image.ANTIALIAS)
        
        #suffix _th to name of thumbnail image
        path_save_thumbnail, extension = os.path.splitext(path_save_image)
        path_save_thumbnail = path_save_thumbnail + '_th.jpg'
        
        image_thumbnail.save(path_save_thumbnail,"JPEG")
        return

    #otherwise: ie, if images are binary files

    #get mode of the image, whether UI16C1 or F32C1 or UC8C1. Rest are ignored
    mode = image_parameters[2] 

    if mode.startswith('F'):
        mode_part = mode[1:3]
    elif mode.startswith('U'):
        mode_part = mode[2:4]
    #if images have mode D64, double data is displayed for files of size > 16
    elif mode.startswith('D'):
        size = image_parameters[1].split(':')    
    	x = int(size[len(size) - 2])
        if x>=16:
            displayData(image_path, image_name, transform_type)
        else:
            global from_display
            from_display = 1
        return
    else:
        print "Error -> mode not recognised",image_name
        return

    #path to save the converted image files    
    path_save_image = 'Images/%s/%s.jpg'%(image_folder,image_name[0:len(image_name)-4])
    
    #path_get_image contains the path from where to retrieve image files.
    #image_folder should be changed to image_path if folders testdata and Dump exist in same location
  
    path_get_image = '/%s/%s/%s'%(path_of_files,image_folder,image_name)
    print path_get_image
    create_direc = '''Images/%s'''%(image_folder)
   
    #create folder to save images
    if not os.path.exists(create_direc):
        os.makedirs(create_direc)

    #get dimensions of image        
    size = image_parameters[1].split(':')
    
    x = int(size[len(size) - 2])                                              
    y = int(size[len(size) - 1])  
 
    try:
        # Use the PIL raw decoder to read the data
        raw_data = open(path_get_image ,'rb').read()
        image_size = (x,y)  
        
        if '8' in mode_part:
            mode_part = 'F;8'
            mode = 'F'
        elif mode_part == '32':
            mode_part = 'F;32F'
            mode = 'F'
        elif mode_part == '16':
            mode_part = 'L;16'
            mode = 'L'            
        else:
            print "Error -> mode not recognised",image_name
            return
        
        #convert and save file as jpg       
        image = Image.fromstring(mode, image_size, raw_data, 'raw', mode_part)
        image.convert('L').save(path_save_image,quality = 95)

        #create and save thumbnail image
        size = 40,40
        image_thumbnail = Image.open(path_save_image)
        image_thumbnail.thumbnail(size, Image.ANTIALIAS)

        #suffix _th to name of thumbnail image
        path_save_thumbnail, extension = os.path.splitext(path_save_image)
        path_save_thumbnail = path_save_thumbnail + '_th.jpg'
        
        image_thumbnail.save(path_save_thumbnail,"JPEG")
    except:
        print "Error -> cannot convert image",image_name
        return
#end of createThumbnail()

#function to display values of D64C1 images
def displayData(image_path,image_name,transform_type):
    global from_display
    from_display = 1
    
    #get number of parameters
    if transform_type == "TRANSLATION":
        no_of_parameters = 2
    elif transform_type == "RIGID2D":
        no_of_parameters = 3
    elif transform_type == "SIMILARITY2D":
        no_of_parameters = 4

    #store double data of image in a list    
    float_data = list()

    #get path of .bin files : image_path contains Dump/shoyu/<algorithm name>/<TestGroup.ScenarioName> and image_name contains the name of the file. image_path is set in the main function in ref image section
    path = '/' + path_of_files +'/'+ image_path + '/' + image_name  #"/root/testdata/" replaced by path_of_files
    
    try:  
	fd = open(path ,'rb')
        for i in range(0,no_of_parameters):           
            raw_data = fd.read(8)  
            float_data.append(struct.unpack("d",raw_data))
        #flatten the list float_data
        float_data = list(itertools.chain(*float_data))
	
        #store image data into javascript variable named <TestGroup><Scenario Name><image file name>
        image_data_folder = image_path[image_path.rfind('/')+1:] + image_name
        image_data_folder = image_data_folder.replace(".","",2)

        global data_array_message
        if no_of_parameters == 2:
            data_array_message += '''
                      $scope.%s = "%f, %f";'''%(image_data_folder,float_data[0],float_data[1])
        elif no_of_parameters == 3:
            data_array_message += '''
                      $scope.%s = "%f, %f, %f";'''%(image_data_folder,float_data[0],float_data[1],float_data[2])
        elif no_of_parameters == 4:
            data_array_message += '''
                      $scope.%s = "%f, %f, %f, %f";'''%(image_data_folder,float_data[0],float_data[1],float_data[2],float_data[3])

    except:
        print "Error in getting double data from file", path
        return
#end of displayData()

#files to read

if len(sys.argv) != 4:
    if len(sys.argv) == 6:
	result_file_2 = str(sys.argv[3])
	result_file_3 = str(sys.argv[4])
	path_of_files = str(sys.argv[5])
	str_2 = result_file_2[-3:]
	str_3 = result_file_3[-3:]
    elif len(sys.argv) == 7:
	result_file_2 = str(sys.argv[3])
	result_file_3 = str(sys.argv[4])
	result_file_4 = str(sys.argv[5])	
	path_of_files = str(sys.argv[6])	
	str_2 = result_file_2[-3:]
	str_3 = result_file_3[-3:]
    else:    	
    	exit()

test_file = str(sys.argv[1])       #raw_input("Enter Test filename(csv file) : ")
result_file = str(sys.argv[2])     #raw_input("Enter Results filename : ")
if len(sys.argv) == 4:
    path_of_files = str(sys.argv[3])   #raw_input("Enter path (eg. /root/testdata/) : ")

'''
path_of_files=os.path.realpath(path_of_file)

if not path_of_file.endswith('/'):
    print "End the path with a /"
    exit()
'''
with open(result_file, 'rb') as rf:

    #open html file to write into
    fh = open('result.html','wb')

    #css styling for web page
    message = '''\
<!DOCTYPE html>
<html ng-app="myApp">
    <head>
        <title>Results</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 70%;
      margin: auto;
  }

.carousel-indicators li {
    display: inline-block;
    width: 48px;
    height: 48px;
    margin: 10px;
    text-indent: 0;
    cursor: pointer;
    border: none;
    border-radius: 50%;
    background-color: #0000ff;
    box-shadow: inset 1px 1px 1px 1px rgba(5,5,0,0.5);    
}
.carousel-indicators .active {
    width: 48px;
    height: 48px;
    margin: 10px;
    background-color: #ffff99;
}

  </style>
	<!--<style>
            body {background-color:#E6F3F7;}
            h2 {color:#10323D;size:40px;}
            table { 
                color: #10323D; 
                font-family: Helvetica, Arial, sans-serif; 
                width: 640px; 
                border-collapse: collapse; 
                border-spacing: 0;
            }
            td, th { 
                border: 1px solid #BDD9F2; 
                height: 30px;
                transition: all 0.3s;  /* Simple transition for hover effect */       
            } 
            th {
                background: #5283A3; 
                font-weight: bold; 
            }
           
            /* Cells in even rows are one color */ 
            tr:nth-child(odd) td { background: #C0DAEB; }   

            /* Cells in odd rows are another (excludes header cells)  */ 
            tr:nth-child(even) td { background: #FEFEFE; }  

            tr td:hover { background: #5283A3; color: #FFF; font-weight: bold;} 
            a {text-decoration:none;}
            .mytable td.red { background-color: red; }   /*#EB6E67*/
        </style>-->
	
    <!-- Bootstrap Core CSS -->
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
	</head>
    <!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>-->
    <script src="angular.min[1].js"></script>

    <body ng-controller="appController">'''
    fh.write(message)	
            
#initialising values    
    slno = 0
    no_of_rows = 0
    no_passed = 0;
    slno_list = list()
    x22 = 0
#to display Summary Table
    fh.write('''
        </br>
        <h2 align="center"> Summary </h2>
        <table border="2px solid black" align="center" style="text-align:center;">
            <tr>
                <th>Sl No</th>
                <th>Test Group</th>
                <th>Total Number of Test Cases</th>
                <th>Passed</th>
                <th>Failed</th>
                <th>Success Ratio %</th>
            </tr>''')
            
#looping to find fields for summary table
            
    for row in rf:
        #start of a Test Group
        if row.startswith('TestGroup') and "end" not in row:
            test_group = row
            no_of_rows += 1
            fh.write('''
            <tr>
                <td>%d</td>
                <td>%s</td> '''%(no_of_rows,test_group[10:].strip()))
                
        #end of a Test Group and writing summary fields in the table       
        elif row.startswith('TestGroup') and "end" in row:
            slno_list.append(slno)
            if slno != 0:
                success_ratio = (no_passed/float(slno)) * 100
                success_ratio = round(success_ratio,2)
            else:
                success_ratio  = 'Not Defined'
            fh.write('''
                <td>%d</td>
                <td>%d</td>
                <td>%d</td>
                <td>%s</td>
            </tr>'''%(slno,no_passed,(slno - no_passed),success_ratio))
            slno = 0
            no_passed = 0
        
        #counting number of passed testcases   
        else:
            row.strip()
            #ignore invalid rows
            if (row=='\n') or (row.startswith('TestCase')) or (row.startswith('[')) or ('Executing' in row) or ('Complete' in row):
                continue
            else:     
                with open(test_file,'rb') as tf:
                    read_testfile = csv.reader(tf, delimiter = ',')    
                    header = next(read_testfile)         
                    for row_testfile in read_testfile:
                        if len(row_testfile)<len(header) or row_testfile[0].startswith('#'):                        
                            continue
			
                        #if row_testfile[1] == test_group[10:].strip() and row_testfile[2] == row.split(',')[0].strip() and row_testfile[0] == "1":             
                            #slno += 1                               
                            #result = row.split(",")[10].strip()                                
                            #if result == "passed":
                                #no_passed += 1  
                            #break              
                
    fh.write('''
        </table>
        </br>''')
        
#initialising values for Data Table       
slno = 0
array_count = 0
source_count = 0
dst_count = 0
ref_count = 0
image_gpu = 0
image_x86 = 0
image_cpu = 0
image_ref = 0
image_omp = 0
size = []
ac2d_size = []
ac3d_size = []
inde = []
data_array_message = ''' '''
gta = 0
yy = defaultdict(lambda: defaultdict(dict))
speed_up = defaultdict(lambda: defaultdict(dict))
x22 = defaultdict(lambda: defaultdict(dict))
with open(test_file,'rb') as tf:                 
    # Reading csv test file
    reader_test = csv.reader(tf, delimiter = ',')
                 
    #getting number of image fields
    header = next(reader_test)
    scenario_description_count = len(header)
    for i in range(3,scenario_description_count):                   
        if "SrcImage" in header[i]:
            source_count += 1
            si = i
        if "DstImage" in header[i]:
            dst_count += 1
            di = i
        if "RefImage" in header[i]:
            ref_count += 1
            ri = i
    source_start = 1
    dst_start = 1
    ref_start = 1	
    '''#get suffix of Source, Dst, Ref images       
    if source_count > 1:
        source_start = int(header[si-source_count+1][8:])
    if dst_count > 1:
        dst_start = int(header[di-dst_count+1][8:])
    if ref_count > 1:
        ref_start = int(header[ri-ref_count+1][8:])'''

#storing angularjs code
js_message = '''<script>
	            var app = angular.module("myApp",[]);
	            app.controller("appController" , function($scope){'''
toggle_images_message = ' '
	        
#write required fields
with open(result_file, 'rb') as rf:	
    read_testfile = csv.reader(rf, delimiter = ',')
    for row in rf:
        print row
        #test_group[10:].strip( == 'Performance'
        #start of a Test Group and to give heading to table    
        if row.startswith('TestGroups') and "end" not in row:
            test_group = row
            array_count += 1
            toggle_images_message += '''
                      $scope.toggleImage%d = true;'''%(array_count)
            if slno_list[array_count-1] != 0:
                fh.write('''
            <div class="panel panel-default">
		<div class="panel-heading">
		<h2 align="center">TestGroup => %s</h2>
		</div>
		<div class = "panel-body">
		<div class="panel-group" id="accordion">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#data%d">Log</a>
                                        </h4>
                                    </div>
		<div id="data%d" class="panel-collapse collapse in">
                                        <div class="panel-body">
                                    
	    '''%(test_group[10:].strip(), array_count, array_count))
	    	
	    	fh.write('''
		
            <div id = "data%d" class='tab-pane fade in active'><button  type="button" ng-click="toggleImage%d=!toggleImage%d">Hide/show Images</button><table class='table table-hover' border="2px solid black" align="center">'''%(array_count,array_count,array_count))
                js_message += '''
                		  
	                $scope.arr%d = ['''%(array_count)

        #ignore invalid rows 
        elif row.startswith('[') or ('Complete' in row) or (row.strip()=='\n'):           
            continue  
        #get name of algorithm   
        elif 'Executing' in row:
            algorithm = row.split()[1]     
        #to give column headings
        elif row.startswith("TestCase"):            
            row_fields = row.split(",")            
            slno = 0            
            fh.write('''
                <tr>
                    <th ng-click = "query%d = 'Slno'; reverseSort%d = !reverseSort%d">Sl no</th>
                    <th ng-click = "query%d = 'ScenarioName'; reverseSort%d = !reverseSort%d">Scenario Name</th>
                    <th>Scenario Description</th>'''%(array_count,array_count,array_count,array_count,array_count,array_count))

            for i in range(1,10):
                query_field = row_fields[i].strip()
                query_field = query_field.replace(".","")
                query_field = query_field.replace(" ","")

                fh.write('''
                    <th ng-click = "query%d = '%s'; reverseSort%d = !reverseSort%d">%s</th>'''%(array_count,query_field,array_count,array_count,row_fields[i].strip()))
            fh.write('''
                    <th>Result </br> <small>Sort By : 
                                            <select ng-model="query%d">
					                            <option value=" " ng-click="reverseSort%d = 'True'" selected>No selection</option>
		                                        <option value="-Result" ng-click="reverseSort%d = 'False'">Failed</option>
		                                        <option value="Result" ng-click="reverseSort%d = 'False'">Passed</option>
		                                    </select>
		                              </small>
		           </th>'''%(array_count,array_count,array_count,array_count))

            with open(test_file,'rb') as tf:                 
                # Reading csv test file
                reader_test = csv.reader(tf, delimiter = ',')
                 
                #getting header and number of scenario description fields
                header = next(reader_test)
                scenario_description_count = len(header)
                
                #write table headings of image fields into html file. The variable toggleImage hides/shows image columns
                for i in range(3,scenario_description_count):
                    if "Image" in header[i]:
                        fh.write('''
                    <th ng-show="toggleImage%d">%s</th>'''%(array_count,header[i]))
                   
            fh.write('''
                </tr>''')
            
        #end of a Test Group and to give table data            
        elif ("end" in row):
            #print slno_list[array_count-1]
	    print 'asdsda'
	    if (1==1): 
		print 'hola'
                fh.write('''
                <tr ng-repeat = "i in arr%d| orderBy:query%d : reverseSort%d">
                    <td>{{i.Slno}}</td>
                    <td>{{i.ScenarioName}}</td>
                    <td style="font-size:10px; font-weight:bold" align="left">			
			            <p ng-click = "toggleShow(i)">&#x271A;</p>
			            <div ng-show ="i.myVar">
			                <ul style="list-style-type:none;">
			                    <li ng-repeat="each in i.ScenarioDescription">{{each}}</li>
			                </ul>
			            </div>
			        </td>
                    <td>{{i.HD}}</td>
                    <td>{{i.KE}}</td>
                    <td>{{i.DH}}</td>
                    <td>{{i.TT}}</td>
                    <td>{{i.RMSE | number:5}}</td>
                    <td>{{i.BRMSE | number:5}}</td>
                    <td>{{i.NoErr}}</td>
                    <td>{{i.MaxErr | number:5}}</td>
                    <td>{{i.MeanErr | number:5}}</td>
                    <td ng-class="{'red' : ({{i.Result | json}} == 'failed')}">{{i.Result}}</td>'''%(array_count,array_count,array_count))
                 
                 
                
                #display SrcImage
                if source_count == 1:
                    fh.write(''' 
                    <td ng-show="toggleImage%d">
                        <a href="{{i.SrcImage.slice(0,i.SrcImage.length-7)+'.jpg'}}" target="_blank">
                            <img ng-src="{{i.SrcImage}}" alt="NA" style="width:40px;height:40px;" align='center'>
                        </a>
                    </td>'''%(array_count))
                else:
                    for j in range(source_start,source_count+source_start):
                        a = j
                        fh.write(''' 
                    <td ng-show="toggleImage%d">
                        <a href="{{i.SrcImage%d.slice(0,i.SrcImage%d.length-7)+'.jpg'}}" target="_blank">
                            <img ng-src="{{i.SrcImage%d}}" alt="NA" style="width:40px;height:40px;" align='center'>
                        </a>
                    </td>'''%(array_count,a,a,a))
                
               
                #print dstImage 

                if dst_count == 1:                    
                    fh.write('''
		    <td>
                    <div ng-show="{{i.DstImage.substr(i.DstImage.length - 1)|json}}==='D' && toggleImage%d">
                            <p ng-bind = "{{i.DstImage.slice(0,i.DstImage.length-1)}}"></p>
		    </div>''' %(array_count))
                    fh.write('''
                    <div ng-show="{{i.DstImage.substr(i.DstImage.length - 1)|json}}==='g' && toggleImage%d">
                        <a href="{{i.DstImage.slice(0,i.DstImage.length-7)+'.jpg'}}" target="_blank">
                            <img ng-src="{{i.DstImage.slice(0,i.DstImage.length-7)+'.jpg'}}" alt="NA" style="width:40px;height:40px;" align='center'>
                        </a>
                    </div>
		    </td>''' %(array_count))
                    

                else:
                    for j in range(dst_start,dst_count+dst_start):
                        a = j
                        fh.write('''
		    <td>
                    <div ng-show="{{i.DstImage%d.substr(i.DstImage%d.length - 1)|json}}==='D' && toggleImage%d">
                        <p ng-bind = "{{i.DstImage%d.slice(0,i.DstImage%d.length-1)}}"></p>
		    </div>'''%(a,a,array_count,a,a))
                        fh.write('''
                    <div ng-show="{{i.DstImage%d.substr(i.DstImage%d.length - 1)|json}}==='g' && toggleImage%d">
                        <a href="{{i.DstImage%d.slice(0,i.DstImage%d.length-7)+'.jpg'}}" target="_blank">
                            <img ng-src="{{i.DstImage%d.slice(0,i.DstImage%d.length-7)+'.jpg'}}" alt="NA" style="width:40px;height:40px;" align='center'>
                        </a>                
                    </div>
		    </td>'''%(a,a,array_count,a,a,a,a))
			

                #print RefImage

                if ref_count == 1:                    
                    fh.write('''
		    <td>
                    <div ng-show="toggleImage%d && {{i.RefImage.substr(i.RefImage.length - 1)|json}}==='D'">
                            <p ng-bind = "{{i.RefImage.slice(0,i.RefImage.length-1)}}"></p>
	            </div>''' %(array_count))
                    fh.write('''
                    <div ng-show="{{i.RefImage.substr(i.RefImage.length - 1)|json}}==='g' && toggleImage%d">
                        <a href="{{i.RefImage.slice(0,i.RefImage.length-7)+'.jpg'}}" target="_blank">
                            <img ng-src="{{i.RefImage.slice(0,i.RefImage.length-7)+'.jpg'}}" alt="NA" style="width:40px;height:40px;" align='center'>
                        </a>
                    </div>
		    </td>''' %(array_count))
                    

                else:
                    for j in range(ref_start,ref_count+ref_start):
                        a = j
                        fh.write('''
		    <td>
                    <div ng-show="{{i.RefImage%d.substr(i.RefImage%d.length - 1)|json}}==='D' && toggleImage%d">
                        <p ng-bind = "{{i.RefImage%d.slice(0,i.RefImage%d.length-1)}}"></p>
	            </div>'''%(a,a,array_count,a,a))
                        fh.write('''
                    <div ng-show="{{i.RefImage%d.substr(i.RefImage%d.length - 1)|json}}==='g' && toggleImage%d">
                        <a href="{{i.RefImage%d.slice(0,i.RefImage%d.length-7)+'.jpg'}}" target="_blank">
                            <img ng-src="{{i.RefImage%d.slice(0,i.RefImage%d.length-7)+'.jpg'}}" alt="NA" style="width:40px;height:40px;" align='center'>
                        </a>                
                    </div>
		    </td>'''%(a,a,array_count,a,a,a,a))
                        
			        
			        
                
               
                
                fh.write('''
                </tr>''')
                fh.write('''
            </table>
	</div></div></div>
        ''') 
                js_message += '''
                    ];'''
		fh.write('''''')
		#print 'hola'			
		if(1==1):#'Performance' in test_group[10:].strip()):
			#print 'hola'
			gpu = defaultdict(dict)
		        x86 = defaultdict(dict)
			ref = defaultdict(dict)
			i=j=k=l=m=0
			size.sort()
			print yy
			for elem in yy:
				print yy[elem]['X86'].values()
			print size
			for sse in size:
				#print elem						
				sse = str(sse)+'x'+str(sse) + str(ext)
				if sse not in ac2d_size:				
					ac2d_size.append(sse)
				#print ac2d_size
			#print ac_size
			#fig, axes = plt.subplots(nrows=2, ncols=3, figsize=(6, 6))
			fh.write('''<div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#graph%d">Graph</a>
                                        </h4>
                                    </div><div id="graph%d" class="panel-collapse collapse">
                                        <div class="panel-body">
                      
				    '''%(array_count, array_count))
			#print 'hola'			
			if(image_ref == 1):
				n_groups = len(inde)
	                	index = np.arange(n_groups)
				bar_width = 0.3
				for elem in yy:
					print elem
					print 'adsad'					
					for xe in size:				
						speed_up[elem]['GPU'][xe] = yy[elem]['REF'][xe]/yy[elem]['GPU'][xe]
						speed_up[elem]['X86'][xe] = yy[elem]['REF'][xe]/yy[elem]['X86'][xe]
					speed_up[elem]['GPU'] = collections.OrderedDict(sorted(speed_up[elem]['GPU'].items()))
					speed_up[elem]['X86'] = collections.OrderedDict(sorted(speed_up[elem]['X86'].items()))	
					rects4 = plt.bar(index, speed_up[elem]['GPU'].values() , bar_width, alpha=0.4, color='b', label='GPU')
					rects5 = plt.bar(index + bar_width, speed_up[elem]['X86'].values() , bar_width, alpha=0.4, color='g', label='X86')			
					autolabel(rects4)
					autolabel(rects5)
					if(1==0):
						#print elem
						plt.xticks(index + bar_width, ac3d_size)
					else:
						#print elem
						plt.xticks(index + bar_width, ac2d_size)
					plt.title('Speed Up : ' + elem)
					plt.xlabel('Image Size')
					plt.ylabel('Speed Up w.r.t. REF')
					plt.legend(loc='upper right', bbox_to_anchor=(1, 1.15))
					#plt.legend()
					if os.path.exists("Images/PerformanceTest"):
			        		plt.savefig('Images/PerformanceTest/speed_up_' + elem + '.png')
					else:
						os.makedirs("Images/PerformanceTest")
						plt.savefig('Images/PerformanceTest/speed_up_' + elem + '.png')
					plt.close()
	
			for elem in yy:
				n_groups = len(inde)
	                	index = np.arange(n_groups)
				bar_width = 0.3
				print elem				
				if(image_gpu == 1):				
					try:
						for xe in size:				
							gpu[xe][i] = yy[elem]['GPU'][xe]
						yy[elem]['GPU'] = collections.OrderedDict(sorted(yy[elem]['GPU'].items()))	
					except:
						print 'invalid log file'				
					rects1 = plt.bar(index, yy[elem]['GPU'].values() , bar_width, alpha=0.4, color='r', label='GPU')
					#print gpu[xe][i]
					autolabel(rects1)
			  		
				if(image_x86 == 1):				
					try:					
						for xe in size:				
							x86[xe][i] = yy[elem]['X86'][xe]
						yy[elem]['X86'] = collections.OrderedDict(sorted(yy[elem]['X86'].items()))
					except:
						print 'invalid log file'				
					rects2 = plt.bar(index + bar_width, yy[elem]['X86'].values() , bar_width, alpha=0.4, color='b', label='X86')					

					autolabel(rects2)
					#print x86[xe][i]
				#print image_ref			  	
				if(image_ref == 1):				
					try:						
						for xe in size:				
							ref[xe][i] = yy[elem]['REF'][xe]
						yy[elem]['REF'] = collections.OrderedDict(sorted(yy[elem]['REF'].items()))
						#rects4 = plt.bar(index + 2*bar_width, yy[elem]['REF'].values() , bar_width, alpha=0.4, color='g', label='REF')		
					except:
						print 'invalid log file'		
					rects3 = plt.bar(index + 2*bar_width, yy[elem]['REF'].values() , bar_width, alpha=0.4, color='g', label='REF')										
					autolabel(rects3)							
			  	'''x86['256'][i] = yy[elem]['X86'][256]
			 	x86['512'][j] = yy[elem]['X86'][512]
			  	x86['1024'][k]= yy[elem]['X86'][1024]
			  	x86['2048'][l]= yy[elem]['X86'][2048]
			  	#x86['4096'][m]= yy[elem]['X86'][4096]
			  	'''
				i+=1
				
				#yy[elem]['X86'] = collections.OrderedDict(sorted(yy[elem]['X86'].items()))
				#rects1 = plt.bar(index, yy[elem]['X86'].values() , bar_width, alpha=0.4, color='b', label='X86')
				if(1==0):
					plt.xticks(index + bar_width, ac3d_size)
				else:
					plt.xticks(index + bar_width, ac2d_size)
				plt.title('Execution Time : ' + elem)
				plt.xlabel('Image Size')
				plt.ylabel('Execution Time (ms)')
				plt.legend(loc=0)
				#plt.legend()
				if os.path.exists('Images/PerformanceTest/' + test_file + "/"):
		        		plt.savefig('Images/PerformanceTest/' + test_file + '/' + elem + '.png')
				else:
					os.makedirs('Images/PerformanceTest/' + test_file + "/")
					plt.savefig('Images/PerformanceTest/' + test_file + '/' + elem + '.png')
				plt.close()
			

			#data1 = gpu['256'].values(), gpu['512'].values(), gpu['1024'].values(), gpu['2048'].values()#, gpu['4096'].values()
			if(image_gpu == 1):
				data1=[]
				red = []		
				for xe in size:
					data1.append(gpu[xe].values())
				plt.boxplot(data1, showmeans=True)
				plt.xticks(inde, ac2d_size)
				plt.title('GPU')
				plt.xlabel('Image Size')
				plt.ylabel('Execution Time (ms)')	
				plt.savefig('Images/PerformanceTest/1.png')
				plt.close() 
			if(image_x86 == 1):
				data2=[]			
				for xe in size:
					data2.append(x86[xe].values()) 
				plt.boxplot(data2, showmeans=True)
				plt.xticks(inde, ac2d_size)
				plt.title('X86')
				plt.xlabel('Image Size')
				plt.ylabel('Execution Time (ms)')	
				plt.savefig('Images/PerformanceTest/2.png')
				plt.close()			
			if(image_ref == 1):
				data4=[]			
				for xe in size:
					data4.append(ref[xe].values())
				plt.boxplot(data4, showmeans=True)
				plt.xticks(inde, ac2d_size)			
				plt.title('REF')
				plt.xlabel('Image Size')
				plt.ylabel('Execution Time (ms)')	
				plt.savefig('Images/PerformanceTest/3.png')
				plt.close()
			merge_plot(1, 'deri', 'U16', 1, 1)
			merge_plot(1, 'val', 'U16', 1, 2)
			merge_plot(1, 'deri', 'F32', 1, 3)
			merge_plot(1, 'val', 'F32', 1, 4)
			merge_plot(1, 'deri', 'U16', 0, 5)
			merge_plot(1, 'val', 'U16', 0, 6)
			merge_plot(1, 'deri', 'F32', 0, 7)
			merge_plot(1, 'val', 'F32', 0, 8)
			#data2 = x86['256'].values(), x86['512'].values(), x86['1024'].values(), x86['2048'].values()#, x86['4096'].values()
		        #plt.boxplot(data2)
			#plt.xticks([1, 2, 3, 4, 5], ['256', '512', '1024', '2048', '4096'])     
			#plt.title('X86')
			#plt.xlabel('Image Size')
			#plt.ylabel('Execution Time')
			#plt.savefig('Images/PerformanceTest/x86.png')
			#plt.close()
			fh.write('''<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">''')
			count = 0
      			for elem in yy:
				fh.write('''
      <li data-target="#myCarousel" data-slide-to="%d" class="active"></li>'''%(count))
				count +=1
			for elem in yy:
				fh.write('''
      <li data-target="#myCarousel" data-slide-to="%d" class="active"></li>'''%(count))
				count +=1
			fh.write('''
      <li data-target="#myCarousel" data-slide-to="%d" class="active"></li>'''%(count))
			fh.write('''
      <li data-target="#myCarousel" data-slide-to="%d" class="active"></li>'''%(count+1))
			if (image_ref == 1):
				fh.write('''
      <li data-target="#myCarousel" data-slide-to="%d" class="active"></li>'''%(count+2))			
			fh.write('''
				    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">''')
			c = 0
			for elem in yy:
				c+=1				
				if (c == 1) :				
					fh.write('''
      <div class="item active">
        <img src="Images/PerformanceTest/%s.png" alt="Chania"  width="460" height="345">
      </div>'''%(elem))
				else:
					fh.write('''

      <div class="item">
        <img src="Images/PerformanceTest/%s.png" alt="Chania" width="460" height="345">
      </div>'''%(elem))
			for elem in yy:
				c+=1				
				if (c == 1) :				
					fh.write('''
      <div class="item active">
        <img src="Images/PerformanceTest/speed_up_%s.png" alt="Chania"  width="460" height="345">
      </div>'''%(elem))
				else:
					fh.write('''

      <div class="item">
        <img src="Images/PerformanceTest/speed_up_%s.png" alt="Chania" width="460" height="345">
      </div>'''%(elem))
			fh.write('''

      <div class="item">
        <img src="Images/PerformanceTest/1.png" alt="Chania" width="460" height="345">
      </div><div class="item">
        <img src="Images/PerformanceTest/2.png" alt="Chania" width="460" height="345">
      </div><div class="item">''')
			if (image_ref == 1): 
				fh.write('''
        <img src="Images/PerformanceTest/3.png" alt="Chania" width="460" height="345">
      </div>''')

			fh.write('''

      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">''')

			
			
			fh.write('''
    
    </div>

    <!-- Left and right controls -->
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div></div></div></div>''')
		fh.write('''</div></div></div></div></div>''')
        #store values of fields in Data Table to javascript array            
        else:
             js_message_image = ' '
	     
	     #get values of fields in the table 
             row_f = row.split(',')
             #print row_fields
	     if(row_f[0]=='\n'):
	     	 continue
             for i in range(0,11):
             	 row_f[i] = row_f[i].strip()
                         
	     if(1==1):#'Performance' in test_group[10:].strip()): 
		 if(row_f[0] == 'TestCase'):
			continue
		 #print row_f[0]
		 if('GPU' in row_f[0]):
		     image_gpu=1
            	     h = row_f[0].find('GPU')
          	 elif('X86' in row_f[0]):
            	     image_x86=1
		     h = row_f[0].find('X86')
		 elif('REF' in row_f[0]):
		     image_ref = 1
		     h = row_f[0].find('REF')
		 elif('OMP' in row_f[0]):
		     image_omp = 1
		     h = row_f[0].find('OMP')
          	 #print h
		 x = row_f[0].find('x')
		 if ('x' in row_f[0][x+1:]):
	             t = row_f[0][x+9:]
		     if('_' in row_f[0][x+1:]):
		     	l = row_f[0][x+1:].find('_')
			print 'holaaaa'			
			ext = row_f[0][x+5:l]
		     else:
			ext = row_f[0][x+5:]
          	 else:
            	     t = row_f[0][x+5:]
		     ext = ''
          	 fe = min(x, h)
		 print ' ext - ' + ext
		 x1  = row_f[0][0:fe] + row_f[0][h+4:x-5] + t
          	 y1 = row_f[0][h:h+3]
          	 z = int(row_f[0][x-4:x])
		 print 'yes' + x1, y1, z #, z, t
		 if z not in size:
		 	size.append(z)
			gta+=1
			inde.append(gta)
		 #print size
		 if ('x' in row_f[0][x+1:]):
		 	x22[x1][y1][z] = 1
 		 ex = row_f[2]
		 if(len(sys.argv)==4):
		 	yy[x1][y1][z] = float(ex)
		 else:
			if(len(sys.argv) == 7):
				median(result_file_2)
				median(result_file_3)
				with open(result_file_4) as fe:
					read_t = csv.reader(fe, delimiter = ',')
					for row_f2 in read_t:
						row_f2 =  map(str.strip, row_f2)
						if(('TestCase') in row_f2) or (len(row_f2)<10 and len(row_f2)!=6) or (row_f2=='\n') or (row_f2=='') :		
							continue
						if('GPU' in row_f2[0]):
							image_gpu=1
					    	     	h = row_f2[0].find('GPU')
					  	elif('X86' in row_f2[0]):
					    	     	image_x86=1
						     	h = row_f2[0].find('X86')
						elif('REF' in row_f2[0]):
							image_ref=1
							h = row_f2[0].find('REF')
												
						x = row_f2[0].find('x')
						if ('x' in row_f2[0][x+1:]):
							t = row_f2[0][x+9:]
							if('_' in row_f2[0][x+1:]):
							     	l = row_f2[0][x+1:].find('_')
								ext = row_f2[0][x+5:l]
							else:
								ext = row_f2[0][x+5:]
					  	else:
					    		t = ''#row_f[0][x+5:]
							ext = ''
						fe = min(x, h)				  		
						x1  = row_f2[0][0:fe] + row_f2[0][h+4:x-5] + t
				  		y1 = row_f2[0][h:h+3]
						print 'med' + x1#, y1, row_f2[0][x-4:x]
				  		z = int(row_f2[0][x-4:x])
						ex = row_f2[2]
						#print ex
						#print 'hola'
						yy[x1][y1][z] = float(ex)
			elif(len(sys.argv) == 6):
				median(result_file_2)
				median(result_file_3)
			'''with open(result_file_2) as fe:
				read_t = csv.reader(fe, delimiter = ',')
				for row_f2 in read_t:
					row_f2 =  map(str.strip, row_f2)
					if(('TestCase') in row_f2) or (len(row_f2)<10 and len(row_f2)!=6) or (row_f2=='\n') or (row_f2=='') :		
						#print len(row_f2), row_f2						
						continue
					if(('Median' in row_f2[0])):
						ex = row_f2[2]
						#print ex
						#print 'hola'
						yy[x1][y1][z] = float(ex)
						continue
					if(len(row_f2) == 6 and ('Median' not in row_f2)):									
						continue
					if('GPU' in row_f[0]):
					        image_gpu=1
				    	     	h = row_f[0].find('GPU')
				  	elif('X86' in row_f[0]):
				    	     	image_x86=1
					     	h = row_f[0].find('X86')
					elif('CPU' in row_f[0]):
					        image_cpu=1
					        h = row_f[0].find('CPU')
				   	elif('REF' in row_f[0]):
					        image_ref = 1
					        h = row_f[0].find('REF')
					x = row_f2[0].find('x')
					if ('x' in row_f2[0][x+1:]):
						t = row_f2[0][x+7:]
					else:
						t = row_f2[0][x+5:]
			  		x1  = row_f2[0][0:h] + row_f2[0][h+4:x-5] + t
			  		y1 = row_f2[0][h:h+3]
					print x1, y1, row_f2[0][x-4:x]
			  		z = int(row_f2[0][x-4:x])'''
             with open(test_file,'rb') as tf:                 
                 #Reading csv test file
                 reader_test = csv.reader(tf, delimiter = ',')
                 
                 #getting header and number of scenario description fields
                 header = next(reader_test)
                 scenario_description_count = len(header)

                 for row_testfile in reader_test:                 
                     #ignore invalid rows
                     if len(row_testfile)<len(header) or row_testfile[0].startswith('#'):
                         continue

                     #find matching rows
                     if (1 == 0) :#row_testfile[1] == test_group[10:].strip() and row_testfile[2] == row.split(',')[0].strip() and row_testfile[0] == "1":                         
                         #slno += 1;  

                         #get fields of Scenario Description 
                         #row_testfile = [key.replace('"', '') for key in row_testfile]
                         
                         #get TransformType field value
                         #for i in range(3,scenario_description_count):
                             #if 'TransformType' in header[i]:
                                #transform_type = row_testfile[i].strip()
                                #break                         
                                                                           
                         #get values of fields in the table 
                         row_fields = row.split(',')
                         for i in range(0,11):
                             row_fields[i] = row_fields[i].strip()
                         
                         #workbook  = xlsxwriter.Workbook('filename.xlsx')
                         #get index of SrcImage field from test file                         
                         for i in range(3,scenario_description_count):
                             if 'SrcImage' in header[i]:
                                 source_image = i
                                 
                                 #Source Image - extract image path, image name and call createThumbnail()
                         
                                 source_find = row_testfile[source_image].rfind('/')      
                                 if source_find < 0:
                                    image_path_source = ' '
                                 else:                            
                                    source_get_index_path = row_testfile[source_image].find(':') 
                                    
                                    #get parameters of image 
                                    image_parameters = row_testfile[source_image][source_get_index_path:].split('::')
                                    
                                    source = row_testfile[source_image][1:source_get_index_path].strip()
                                    image_name = source.split('/')
                                    image_path_source = row_testfile[source_image][1:source_find].strip()  
           
                                    image_folder = image_name[len(image_name) - 2]
                                    
                                    #call function to create thumbnail images
                                    #createThumbnail(image_path_source,image_folder,image_name[len(image_name) - 1],image_parameters, transform_type)
                                    #image path to store in javascript array
                                    image_path_source = 'Images/' + image_folder + '/' + image_name[len(image_name)-1][:-4] + '_th.jpg'
                                 js_message_image += '''
                        %s : "%s",'''%(header[i],image_path_source)
                                    
                                 
                         #Dst Image - extract image path, image name and call displayData() 
                         loop_var = 0  
                         files_in_path = list()
			 #image_path_dst = 'Dump/%s/%s.%s'%(algorithm,row_testfile[1],row_testfile[2])

			 #get dst.bin file names after checking if they exist
                         from os import listdir 
                         #mypath = path_of_files +'/' + image_path_dst
                         #if os.path.exists(mypath):
                             #for files in os.listdir(mypath):
                                 #if files.endswith(".bin"):
                                     #files_in_path.append(files)
                                 #else:
                                     #files_in_path.append(" ")
       			     #files_in = files_in_path.sort()
			 if len(files_in_path) == 0:
			     #files_in_path.append(" ")
			     files_in_path = [" "," "]
                         for i in range(3,scenario_description_count):
                             if 'DstImage' in header[i]:
                                 dst_image = i
                                 image_parameters = row_testfile[dst_image].split('::')
                                 image_folder = '%s.%s'%(row_testfile[1],row_testfile[2])
                                 
                                 #image_path_dst = 'Dump/%s/%s.%s'%(algorithm,row_testfile[1],row_testfile[2])
                                 image_name = header[i]

                                 
                                    
                                 #checking if multiple Dst images are there 
                                 if image_name.endswith("e"):
				    
                                    image_name = files_in_path[0]        
                                 else:
                                    #image_name1 = "dst%s.bin"%(str(int(image_name[-1])))         
                                    image_name = files_in_path[loop_var]
                                    loop_var += 1                            
                                 
                                 #call createThumbnail() to get double data or jpg files of images

                                 image_name.strip()
                                 if image_name == ' ':
                                    image_path_dst = ' '
                                 else:				    
                                    createThumbnail(image_path_dst,image_folder,image_name,image_parameters, transform_type)                                                                    
                                    if from_display == 1:
					image_name = image_name.replace('.','')
                                        image_path_dst = '%s%s'%(row_testfile[1],row_testfile[2]) + image_name + 'D'
                                    else:
					image_name1 = image_name[:-4]
                                        image_path_dst = 'Images/' + image_folder + '/' + image_name1 + '_th.jpg'                   

                                 from_display = 0
                                 js_message_image += '''                 
                        %s : "%s",'''%(header[i],image_path_dst) 
                          
                      
                  
                         # Reference Image - extract image path, image name and call createThumbnail()    
                         for i in range(3,scenario_description_count):
                             if 'RefImage' in header[i]:
                                 ref_image = i
                                 
                                 ref_find = row_testfile[ref_image].rfind('/')
                                 
                                 #check if path is given for Ref image or not
                                 #if path is not given get double data for image from <TestGroup>.<ScenarioName> folder
                                 if ref_find < 0:                         
                                    image_path_ref = ' '
                                    
                                 #if path is specified for Ref image   
                                 else:
                                    ref_get_index_path = row_testfile[ref_image].find(':')
                                    image_parameters = row_testfile[ref_image][ref_get_index_path+1:].split('::')
                                    
                                    ref = row_testfile[ref_image][1:ref_get_index_path].strip()
                                    image_name = ref.split('/')

                                    image_path_ref = row_testfile[ref_image][1:ref_find].strip()
                                    image_folder = image_name[len(image_name)-2]  
                                            
                                    #createThumbnail(image_path_ref,image_folder,image_name[len(image_name)-1],image_parameters, transform_type) 
                                     
                                    #get image path to store in javascript array                           
                                    if from_display == 1:
                                        image_name = str(image_name[len(image_name)-1]).replace('.','')
                                        image_path_ref = '%s'%(image_folder.replace(".","")) + image_name + 'D'

                                    else:
                                        image_path_ref = 'Images/' + image_folder + '/' + image_name[len(image_name)-1][:-4] + '_th.jpg'                   
                                    from_display = 0

                                 js_message_image += '''                     
                        %s : "%s",'''%(header[i],image_path_ref)




                         #store values in javascript array
                         js_message += '''
                    {

                        Slno : %d,
                        ScenarioName:"%s",
                        ScenarioDescription :['''%(int(slno),row_fields[0].rstrip())
                         for i in range(3, scenario_description_count):
                             js_message += '''
                                              "[%s => %s]", '''%(header[i],row_testfile[i])

                         js_message += '''
                                             ],
                        HD : %f,
                        KE : %f,
                        DH : %f,
                        TT : %f,
                        RMSE : %f,
                        BRMSE : %f,
                        NoErr : %f,
                        MaxErr : %f,
                        MeanErr :%f,
                        Result : "%s",'''%(float(row_fields[1]),float(row_fields[2]),float(row_fields[3]),float(row_fields[4]),float(row_fields[5]),float(row_fields[6]),float(row_fields[7]),float(row_fields[8]),float(row_fields[9]),row_fields[10])
                         js_message += js_message_image + '''
                    },''' 
                         break        		
#writing javascript array code to html file
fh.write(js_message)
#writing double data containing variables to html file
fh.write("\n")
fh.write(data_array_message)
#javascript code for toggling image columns
fh.write("\n")
message = toggle_images_message
#javascript code for hiding/displaying scenario description on button click 
message +='''

		              $scope.myVar = true;
		              $scope.toggleShow = function(user){
  		                  user.myVar =!user.myVar;
                      };

	   	        });

	    </script>
<!-- jQuery -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>  
	</body>
</html>''' 

fh.write(message)
fh.close()
print "Opening in Firefox browser!!!"
#to select browser and open the web page
#b = webbrowser.get('Firefox')
#b.open_new_tab('result.html')
print "Done"
