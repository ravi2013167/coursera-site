#importing modules
import csv
import sys
import webbrowser
import os
import struct
import itertools
import PIL.Image
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from pylab import *
import collections
from collections import defaultdict

csv_file = sys.argv[1]
log_file = sys.argv[2]
median_count = int(sys.argv[3])
median = []
index = {}
if(median_count>0):
 for i in range(0, median_count):
	median.append(sys.argv[i+4])
config_flag = int(sys.argv[median_count+4])

if(config_flag == 1):
	config_file = sys.argv[median_count + 5]
	with open(config_file, 'rb') as cof:
		conf_reader = csv.reader(cof, delimiter = ',')
		header_conf = next(conf_reader)
		for data in header_conf:
			index[data] = 0	

plot_dict = defaultdict(lambda: defaultdict(dict))

with open(csv_file , 'rb') as cf:
	csv_reader = csv.reader(cf, delimiter = ',')
	header = next(csv_reader)	
	scenario_description_count = len(header)
	image_dim_index = 0
	trans_type_index = 0
	
	for data in header_conf:
		count = 0 
		for columns in header:
			count += 1
			if(data in columns):
				break
			index[data] += 1
			if(count == scenario_description_count):
				print 'Invalid config file'
				#exit()
	
	for columns in header:
		image_dim_index += 1
		if('SrcImage' in columns):
			break
	
	for row_csvfile in cf:
		
		if len(row_csvfile)<len(header) or row_csvfile[0].startswith('#'):
			continue
		
		row_csvfile = row_csvfile.split(',')
		if(':::' in row_csvfile[image_dim_index]):
			row_image_dim = row_csvfile[image_dim_index].split(':::')	
		else:
			row_image_dim = row_csvfile[image_dim_index].split('::')
		print row_image_dim[1]
		plot_array = ''
		for data in header_conf:
			plot_array += row_csvfile[index[data]]
		print plot_array
		with open(log_file, 'rb') as lf:
			log_reader = csv.reader(lf, delimiter = ',')
			log_header = next(log_reader)
			log_description_count = len(log_header)
			for row_logfile in lf:
				if len(row_logfile)<len(log_header) or row_logfile[0].startswith('#'):
					continue
				row_logfile = row_logfile.split(',')
				if(row_csvfile[2] in row_logfile[0]):	
					plot_dict[plot_array][row_csvfile[3]][row_image_dim[1]] = float(row_logfile[2])
print plot_dict
